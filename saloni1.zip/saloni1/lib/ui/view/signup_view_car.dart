/*import 'package:compound/ui/widgets/busy_button.dart';
import 'package:flutter/cupertino.dart';
import 'signup_view.dart';
import 'package:compound/viewmodels/signup_view_model.dart';
class SignUpViewCar extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return BusyButton(
      title: 'Sign Up',
      busy: model.busy,
      onPressed: () {
        model.signUp(
            email: emailController.text,
            password: passwordController.text,
            fullName: fullNameController.text);
      },
    )
  }
}

 */
